import React from 'react';
import { Instagram, Linkedin, Globe, ArrowUp } from 'lucide-react';
import { photographerInfo } from '../mock';

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-dark border-t border-accent/20">
      <div className="container-artworld">
        {/* Main Footer Content */}
        <div className="py-16 grid lg:grid-cols-4 gap-12">
          {/* Brand Section */}
          <div className="lg:col-span-2">
            <h3 className="artist-name text-2xl mb-4">{photographerInfo.name}</h3>
            <p className="body-text text-gray-400 mb-6 max-w-md">
              Professional food and product photographer creating compelling visual stories 
              that elevate brands and connect with audiences.
            </p>
            
            {/* Social Links */}
            <div className="flex space-x-4">
              <a
                href={photographerInfo.socialLinks.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="w-12 h-12 bg-white/10 rounded-lg flex items-center justify-center text-gray-400 hover:text-accent hover:bg-accent/10 transition-all duration-200"
              >
                <Instagram size={20} />
              </a>
              <a
                href={photographerInfo.socialLinks.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="w-12 h-12 bg-white/10 rounded-lg flex items-center justify-center text-gray-400 hover:text-accent hover:bg-accent/10 transition-all duration-200"
              >
                <Linkedin size={20} />
              </a>
              <a
                href={photographerInfo.socialLinks.behance}
                target="_blank"
                rel="noopener noreferrer"
                className="w-12 h-12 bg-white/10 rounded-lg flex items-center justify-center text-gray-400 hover:text-accent hover:bg-accent/10 transition-all duration-200"
              >
                <Globe size={20} />
              </a>
            </div>
          </div>

          {/* Navigation Links */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {[
                { label: 'Home', id: 'home' },
                { label: 'About', id: 'about' },
                { label: 'Portfolio', id: 'portfolio' },
                { label: 'Services', id: 'services' },
                { label: 'Contact', id: 'contact' }
              ].map((link) => (
                <li key={link.id}>
                  <button
                    onClick={() => scrollToSection(link.id)}
                    className="nav-link text-gray-400 hover:text-accent transition-colors duration-200"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-6">Get In Touch</h4>
            <div className="space-y-3">
              <div>
                <p className="caption-text text-gray-500 mb-1">Email</p>
                <a 
                  href={`mailto:${photographerInfo.email}`}
                  className="text-gray-400 hover:text-accent transition-colors duration-200"
                >
                  {photographerInfo.email}
                </a>
              </div>
              <div>
                <p className="caption-text text-gray-500 mb-1">Phone</p>
                <a 
                  href={`tel:${photographerInfo.phone}`}
                  className="text-gray-400 hover:text-accent transition-colors duration-200"
                >
                  {photographerInfo.phone}
                </a>
              </div>
              <div>
                <p className="caption-text text-gray-500 mb-1">Location</p>
                <p className="text-gray-400">{photographerInfo.location}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="border-t border-white/10 py-6 flex flex-col md:flex-row justify-between items-center">
          <p className="caption-text text-gray-500 text-center md:text-left">
            © 2025 {photographerInfo.name}. All rights reserved.
          </p>
          
          <div className="flex items-center space-x-6 mt-4 md:mt-0">
            <button
              onClick={scrollToTop}
              className="flex items-center space-x-2 text-accent hover:text-white transition-colors duration-200 group"
            >
              <span className="caption-text">Back to top</span>
              <ArrowUp size={16} className="group-hover:-translate-y-1 transition-transform duration-200" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;