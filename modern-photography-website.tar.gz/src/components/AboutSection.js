import React from 'react';
import { photographerInfo } from '../mock';

const AboutSection = () => {
  return (
    <section id="about" className="section-spacing-large bg-dark">
      <div className="container-artworld">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div className="space-y-8 animate-slide-in-left">
            <div>
              <div className="type-indicator text-accent mb-4">
                About Me
              </div>
              <h2 className="hero-title text-4xl mb-6">
                Capturing Stories Through
                <span className="text-accent block">Food & Products</span>
              </h2>
            </div>

            <div className="space-y-6">
              <p className="body-text text-gray-300 leading-relaxed">
                With over 8 years of experience in food and product photography, I've had the privilege 
                of working with renowned restaurants, emerging food brands, and innovative product companies. 
                My passion lies in creating images that don't just showcase products—they tell stories and 
                evoke emotions.
              </p>

              <p className="body-text text-gray-300 leading-relaxed">
                Every photograph is carefully crafted with attention to lighting, composition, and styling. 
                I believe that great photography goes beyond technical excellence; it captures the essence 
                of what makes each brand unique and connects with their audience on a deeper level.
              </p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-8 pt-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-accent mb-2">500+</div>
                <div className="caption-text">Projects Completed</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-accent mb-2">150+</div>
                <div className="caption-text">Happy Clients</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-accent mb-2">8+</div>
                <div className="caption-text">Years Experience</div>
              </div>
            </div>
          </div>

          {/* Right Content - Images */}
          <div className="animate-slide-in-right">
            <div className="relative">
              {/* Main Image */}
              <div className="aspect-[4/5] rounded-lg overflow-hidden image-overlay">
                <img
                  src="https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&q=80"
                  alt="Food photography workspace"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Secondary Image - Overlapping */}
              <div className="absolute -bottom-8 -left-8 w-48 h-48 rounded-lg overflow-hidden glass border-4 border-black">
                <img
                  src="https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=400&q=80"
                  alt="Product photography setup"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Decorative Elements */}
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-accent/10 rounded-full blur-xl"></div>
              <div className="absolute -bottom-12 -right-12 w-32 h-32 bg-accent/5 rounded-full blur-2xl"></div>
            </div>
          </div>
        </div>

        {/* Quote Section */}
        <div className="mt-24 text-center">
          <blockquote className="text-2xl lg:text-3xl font-light text-gray-200 italic max-w-4xl mx-auto leading-relaxed">
            "I believe every dish has a story to tell, every product has a personality to reveal. 
            My job is to capture that essence and present it in a way that speaks to your audience."
          </blockquote>
          <div className="mt-8">
            <div className="artist-name text-xl">— {photographerInfo.name}</div>
            <div className="caption-text mt-2">{photographerInfo.title}</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;