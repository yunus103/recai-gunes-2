import React, { useState, useEffect } from 'react';
import { ArrowRight, Instagram, Linkedin, Globe } from 'lucide-react';
import { photographerInfo } from '../mock';

const HeroSection = () => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  
  const backgroundImages = [
    "https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=1920&q=80", // Food photography
    "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=1920&q=80", // Product photography
    "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=1920&q=80", // Food styling
    "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=1920&q=80", // Coffee products
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % backgroundImages.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [backgroundImages.length]);

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Images */}
      <div className="absolute inset-0">
        {backgroundImages.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentImageIndex ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <img
              src={image}
              alt={`Background ${index + 1}`}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/50"></div>
          </div>
        ))}
      </div>

      {/* Content */}
      <div className="container-artworld relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-screen py-20">
          {/* Left Content */}
          <div className="space-y-8 animate-fade-in-up">
            <div>
              <h1 className="hero-title text-white mb-4">
                {photographerInfo.name}
              </h1>
              <h2 className="artist-name text-2xl mb-6">
                {photographerInfo.title}
              </h2>
            </div>
            
            <p className="body-text text-gray-200 max-w-xl leading-relaxed">
              {photographerInfo.bio}
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={() => scrollToSection('portfolio')}
                className="btn-primary group"
              >
                View Portfolio
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform duration-200" />
              </button>
              
              <button
                onClick={() => scrollToSection('contact')}
                className="btn-inverse"
              >
                Get in Touch
              </button>
            </div>
          </div>

          {/* Right Content - Featured Image */}
          <div className="hidden lg:block animate-slide-in-right">
            <div className="relative">
              <div className="aspect-[4/5] rounded-lg overflow-hidden image-overlay">
                <img
                  src="https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=600&q=80"
                  alt="Featured work"
                  className="w-full h-full object-cover"
                />
              </div>
              
              {/* Floating Badge */}
              <div className="absolute -bottom-6 -right-6 glass-light rounded-lg p-4">
                <div className="text-center">
                  <div className="type-indicator text-accent mb-1">Experience</div>
                  <div className="text-2xl font-bold">8+ Years</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Social Links - Vertical */}
      <div className="absolute left-8 top-1/2 -translate-y-1/2 hidden xl:block">
        <div className="flex flex-col items-center space-y-6">
          {/* Top Line */}
          <div className="w-px h-20 bg-accent/50"></div>
          
          {/* Social Icons */}
          <div className="flex flex-col space-y-4">
            <a
              href={photographerInfo.socialLinks.instagram}
              target="_blank"
              rel="noopener noreferrer"
              className="text-accent hover:text-white transition-colors duration-200 hover:scale-110 transform"
            >
              <Instagram size={20} />
            </a>
            <a
              href={photographerInfo.socialLinks.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="text-accent hover:text-white transition-colors duration-200 hover:scale-110 transform"
            >
              <Linkedin size={20} />
            </a>
            <a
              href={photographerInfo.socialLinks.behance}
              target="_blank"
              rel="noopener noreferrer"
              className="text-accent hover:text-white transition-colors duration-200 hover:scale-110 transform"
            >
              <Globe size={20} />
            </a>
          </div>
          
          {/* Bottom Line */}
          <div className="w-px h-20 bg-accent/50"></div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-accent rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;