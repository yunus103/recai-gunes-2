import React, { useState } from 'react';
import { Send, MapPin, Phone, Mail, Clock, ArrowRight } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { toast } from 'sonner';
import { photographerInfo } from '../mock';

const ContactSection = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
    projectType: 'food'
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    toast.success('Message sent successfully! I\'ll get back to you within 24 hours.');
    
    // Reset form
    setFormData({
      name: '',
      email: '',
      subject: '',
      message: '',
      projectType: 'food'
    });
    
    setIsSubmitting(false);
  };

  return (
    <section id="contact" className="section-spacing-large">
      <div className="container-artworld">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="type-indicator text-accent mb-4">
            Get In Touch
          </div>
          <h2 className="hero-title text-4xl mb-6">
            Let's Create Something
            <span className="text-accent block">Amazing Together</span>
          </h2>
          <p className="body-text text-gray-300 max-w-2xl mx-auto">
            Ready to bring your vision to life? I'd love to hear about your project 
            and discuss how we can create stunning visuals for your brand.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16">
          {/* Contact Form */}
          <div className="animate-slide-in-left">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Project Type Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-3">
                  Project Type
                </label>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { value: 'food', label: 'Food Photography' },
                    { value: 'product', label: 'Product Photography' }
                  ].map((type) => (
                    <button
                      key={type.value}
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, projectType: type.value }))}
                      className={`p-4 rounded-lg border-2 transition-all duration-200 ${
                        formData.projectType === type.value
                          ? 'border-accent bg-accent/10 text-accent'
                          : 'border-gray-600 text-gray-300 hover:border-gray-500'
                      }`}
                    >
                      {type.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Name and Email */}
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">
                    Name *
                  </label>
                  <Input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="bg-dark border-gray-600 text-white focus:border-accent"
                    placeholder="Your full name"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                    Email *
                  </label>
                  <Input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="bg-dark border-gray-600 text-white focus:border-accent"
                    placeholder="your@email.com"
                  />
                </div>
              </div>

              {/* Subject */}
              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-gray-300 mb-2">
                  Subject *
                </label>
                <Input
                  type="text"
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleInputChange}
                  required
                  className="bg-dark border-gray-600 text-white focus:border-accent"
                  placeholder="Project inquiry"
                />
              </div>

              {/* Message */}
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-2">
                  Message *
                </label>
                <Textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  required
                  rows={6}
                  className="bg-dark border-gray-600 text-white focus:border-accent resize-none"
                  placeholder="Tell me about your project, timeline, and any specific requirements..."
                />
              </div>

              {/* Submit Button */}
              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-accent text-black hover:bg-accent-hover font-medium py-6 text-lg"
              >
                {isSubmitting ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-black mr-2"></div>
                    Sending Message...
                  </>
                ) : (
                  <>
                    Send Message
                    <Send size={20} className="ml-2" />
                  </>
                )}
              </Button>
            </form>
          </div>

          {/* Contact Information */}
          <div className="animate-slide-in-right">
            <div className="space-y-8">
              {/* Contact Details */}
              <div className="glass rounded-2xl p-8">
                <h3 className="text-xl font-semibold text-white mb-6">Contact Information</h3>
                
                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Mail size={20} className="text-accent" />
                    </div>
                    <div>
                      <h4 className="font-medium text-white mb-1">Email</h4>
                      <p className="text-gray-300">{photographerInfo.email}</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Phone size={20} className="text-accent" />
                    </div>
                    <div>
                      <h4 className="font-medium text-white mb-1">Phone</h4>
                      <p className="text-gray-300">{photographerInfo.phone}</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <MapPin size={20} className="text-accent" />
                    </div>
                    <div>
                      <h4 className="font-medium text-white mb-1">Location</h4>
                      <p className="text-gray-300">{photographerInfo.location}</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Clock size={20} className="text-accent" />
                    </div>
                    <div>
                      <h4 className="font-medium text-white mb-1">Response Time</h4>
                      <p className="text-gray-300">Within 24 hours</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="glass rounded-2xl p-8">
                <h3 className="text-xl font-semibold text-white mb-6">Quick Actions</h3>
                
                <div className="space-y-4">
                  <a
                    href={`mailto:${photographerInfo.email}?subject=Photography Inquiry`}
                    className="flex items-center justify-between p-4 bg-white/5 rounded-lg hover:bg-white/10 transition-colors duration-200 group"
                  >
                    <span className="text-gray-300 group-hover:text-white">Send Quick Email</span>
                    <ArrowRight size={16} className="text-accent group-hover:translate-x-1 transition-transform duration-200" />
                  </a>
                  
                  <a
                    href={`tel:${photographerInfo.phone}`}
                    className="flex items-center justify-between p-4 bg-white/5 rounded-lg hover:bg-white/10 transition-colors duration-200 group"
                  >
                    <span className="text-gray-300 group-hover:text-white">Call Now</span>
                    <ArrowRight size={16} className="text-accent group-hover:translate-x-1 transition-transform duration-200" />
                  </a>
                  
                  <a
                    href="#portfolio"
                    onClick={(e) => {
                      e.preventDefault();
                      document.getElementById('portfolio')?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="flex items-center justify-between p-4 bg-white/5 rounded-lg hover:bg-white/10 transition-colors duration-200 group"
                  >
                    <span className="text-gray-300 group-hover:text-white">View Portfolio</span>
                    <ArrowRight size={16} className="text-accent group-hover:translate-x-1 transition-transform duration-200" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;